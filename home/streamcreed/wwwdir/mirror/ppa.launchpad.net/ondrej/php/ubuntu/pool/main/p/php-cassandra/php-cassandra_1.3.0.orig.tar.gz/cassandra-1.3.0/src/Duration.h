#ifndef PHP_DRIVER_DURATION_H
#define PHP_DRIVER_DURATION_H

void php_driver_duration_init(INTERNAL_FUNCTION_PARAMETERS);

#endif
