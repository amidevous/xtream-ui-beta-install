<?php

// [default config]
// DO NOT rename/delete/modify this file which will be overwritten when upgrade
// See config.example.php instead


// width of graph for free or usage blocks
$config['percent_graph_width'] = 120;
$config['percent_graph_type'] = 'used'; // either 'used' or 'free'

// only enable if you have password protection for admin page
// enabling this option will cause user to eval() whatever code they want
$config['enable_eval'] = false;

