/**
 * Main SDK entry point.
 */

'use strict';

require('mag-configs');

// load default plugins
// and run default tasks
module.exports = require('magsdk/default');
