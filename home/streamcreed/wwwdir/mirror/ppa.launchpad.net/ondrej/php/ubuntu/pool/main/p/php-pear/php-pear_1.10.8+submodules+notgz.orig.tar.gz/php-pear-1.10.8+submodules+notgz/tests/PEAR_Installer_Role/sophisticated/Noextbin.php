<?php
class PEAR_Installer_Role_Noextbin extends PEAR_Installer_Role_Common{}
