.. ref-manage

======
manage
======

boto.manage
-----------

.. automodule:: boto.manage
   :members:   
   :undoc-members:

boto.manage.cmdshell
--------------------

.. automodule:: boto.manage.cmdshell
   :members:   
   :undoc-members:

boto.manage.propget
-------------------

.. automodule:: boto.manage.propget
   :members:   
   :undoc-members:

boto.manage.server
------------------

.. automodule:: boto.manage.server
   :members:   
   :undoc-members:

boto.manage.task
----------------

.. automodule:: boto.manage.task
   :members:   
   :undoc-members:

boto.manage.volume
------------------

.. automodule:: boto.manage.volume
   :members:   
   :undoc-members:
