This directory contains images specific for resolution 720*480
