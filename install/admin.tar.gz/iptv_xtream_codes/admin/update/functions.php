<?php

function getAllChannels() {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `streams` WHERE `type` = '1' ORDER BY `stream_display_name` ASC;");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return[] = $row;
        }
    }
    return $return;
}

function getCategoriesByID($id) {
    global $db;
    $return = Array();
    $result = $db->query("SELECT * FROM `stream_categories` WHERE `id` = '$id';");
    if (($result) && ($result->num_rows > 0)) {
        while ($row = $result->fetch_assoc()) {
            $return = $row;
        }
    }
    return $return;
}

?>