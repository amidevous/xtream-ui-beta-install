<?php
include "functions.php";
if (!isset($_SESSION['user_id'])) { header("Location: ./login.php"); exit; }
if (isset($_POST["submit_series"])) {
    
	
	
	if (isset($_POST["edit"])) {
        $rArray = getStream($_POST["edit"]);
        unset($rArray["id"]);
    } else {
        $rArray = Array("title" => "", "category_id" => "", "cover" => "","genre" => "", "plot" => "", "cast" => "", "rating" => 0, "director" => "", "releaseDate" => "", "last_modified" => 0, "seasons" => "", "backdrop_path" => "", "youtube_trailer" => "");
    }
	if (isset($_POST["title"])) {
        $rArray["title"] = $_POST["title"];
        unset($_POST["title"]);
    } else {
        $rArray["title"] = 0;
    }
    
    if (isset($_POST["category_id"])) {
        $rArray["category_id"] = $_POST["category_id"];
        unset($_POST["category_id"]);
    } else {
        $rArray["category_id"] = "";
    }
    if (isset($_POST["cover"])) {
        $rArray["cover"] = $_POST["cover"];
        unset($_POST["cover"]);
    } else {
        $rArray["cover"] = "";
    }
    if (isset($_POST["genre"])) {
        $rArray["genre"] = $_POST["genre"];
        unset($_POST["genre"]);
    } else {
        $rArray["genre"] = "";
    }
    if (isset($_POST["plot"])) {
        $rArray["plot"] = $_POST["plot"];
        unset($_POST["plot"]);
    } else {
        $rArray["plot"] = "";
    }
    if (isset($_POST["cast"])) {
        $rArray["cast"] = $_POST["cast"];
        unset($_POST["cast"]);
    } else {
        $rArray["cast"] = "";
    }
    if (isset($_POST["rating"])) {
        $rArray["rating"] = intval($_POST["rating"]);
        unset($_POST["rating"]);
    } else {
        $rArray["rating"] = 0;
    }
	if (isset($_POST["director"])) {
        $rArray["director"] = $_POST["director"];
        unset($_POST["director"]);
    } else {
        $rArray["director"] = 0;
    }
	if (isset($_POST["releaseDate"])) {
        $rArray["releaseDate"] = ($_POST["releaseDate"]);
        unset($_POST["releaseDate"]);
    } else {
        $rArray["releaseDate"] = "";
    }
	if (isset($_POST["last_modified"])) {
        $rArray["last_modified"] = intval($_POST["last_modified"]);
        unset($_POST["last_modified"]);
    } else {
        $rArray["last_modified"] = 0;
    }
	if (isset($_POST["seasons"])) {
        $rArray["seasons"] = ($_POST["seasons"]);
        unset($_POST["seasons"]);
    } else {
        $rArray["seasons"] = 0;
    }
	if (isset($_POST["backdrop_path"])) {
        $rArray["backdrop_path"] = ($_POST["backdrop_path"]);
        unset($_POST["backdrop_path"]);
    } else {
        $rArray["backdrop_path"] = "";
    }
	if (isset($_POST["youtube_trailer"])) {
        $rArray["youtube_trailer"] = ($_POST["youtube_trailer"]);
        unset($_POST["youtube_trailer"]);
    } else {
        $rArray["youtube_trailer"] = "";
    }
	
    foreach($_POST as $rKey => $rValue) {
        if (isset($rArray[$rKey])) {
            $rArray[$rKey] = $rValue;
        }
    }
	
	
	
    $rCols = "`".implode('`,`', array_keys($rArray))."`";
    foreach (array_values($rArray) as $rValue) {
        isset($rValues) ? $rValues .= ',' : $rValues = '';
        if (is_array($rValue)) {
            $rValue = json_encode($rValue);
        }
        if (is_null($rValue)) {
            $rValues .= 'NULL';
        } else {
            $rValues .= '\''.$db->real_escape_string($rValue).'\'';
        }
    }
    if (isset($_POST["edit"])) {
        $rCols = "`id`,".$rCols;
        $rValues = $_POST["edit"].",".$rValues;
    }
	
	//print_r($rCols);
	//print_r($rValues);
	
	
    $rQuery = "REPLACE INTO `series`(".$rCols.") VALUES(".$rValues.");";
    //print_r($rQuery);
	//exit;
	if ($db->query($rQuery)) {
        if (isset($_POST["edit"])) {
            $rInsertID = intval($_POST["edit"]);
        } else {
            $rInsertID = $db->insert_id;
        }
    }
	if (isset($rInsertID)) {
		$_STATUS = 0;
    } else {
        $_STATUS = 1;
    }
    if (!isset($_GET["id"])) {
        $_GET["id"] = $rInsertID;
    }
	}
include "header.php"; ?>
        <div class="wrapper boxed-layout">
            <div class="container-fluid">
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <a href="./series.php<?php if (isset($_GET["category"])) { echo "?category=".$_GET["category"]; } ?>"><li class="breadcrumb-item"><i class="mdi mdi-backspace"></i> Back to Series</li></a>
                                </ol>
                            </div>
                            <h4 class="page-title"><?php if (isset($rSeries)) { echo "Edit"; } else { echo "Add"; } ?> VOD</h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
                <div class="row">
                    <div class="col-xl-12">
                        <?php if ((isset($_STATUS)) && ($_STATUS == 0)) { ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            Series operation was completed successfully.
                        </div>
                        <?php } else if ((isset($_STATUS)) && ($_STATUS > 0)) { ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            There was an error performing this operation! Please check the form entry and try again.
                        </div>
                        <?php } ?>
                        <div class="card">
                            <div class="card-body">
                                <form action="./addseries.php<?php if (isset($_GET["id"])) { echo "?id=".$_GET["id"]; } ?>" method="POST" id="Series_form">
                                    <?php if (isset($rSeries)) { ?>
                                    <input type="hidden" name="edit" value="<?=$rSeries["id"]?>" />
                                    <?php } ?>
                                    
                                    <div id="basicwizard">

                                            <div class="tab-pane" id="stream-details">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="title">Title</label>
                                                            <div class="col-md-8">
                                                                <input type="text" required class="form-control" id="title" name="title" value="<?php if (isset($rSeries)) { echo $rSeries["title"]; } ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="category_id">Category Name</label>
                                                            <div class="col-md-8">
                                                                <select name="category_id" id="category_id" class="form-control" data-toggle="select2">
																    <option value="">No Category</option>
                                                                    <?php foreach (getCategories("series") as $rCategory) { ?>
                                                                    <option <?php if (isset($rSeries)) { if (intval($rSeries["category_id"]) == intval($rCategory["id"])) { echo "selected "; } } else if ((isset($_GET["category"])) && ($_GET["category"] == $rCategory["id"])) { echo "selected "; } ?>value="<?=$rCategory["id"]?>"><?=$rCategory["category_name"]?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="stream_icon">Cover</label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="cover" name="cover" value="<?php if (isset($rSeries)) { echo $rSeries["cover"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="movie_propeties">Genre</label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="genre" name="genre" value="<?php if (isset($rSeries)) { echo $rSeries["genre"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="target_container">Plot</label>
                                                            <div class="col-md-8">
                                                                <textarea class="form-control" id="plot" name="plot" rows="3" ><?php if (isset($rSeries)) { echo $rSeries["plot"]; } ?></textarea>
                                                           </div>
                                                        </div>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="notes">Cast</label>
                                                            <div class="col-md-8">
                                                                <textarea id="cast" name="cast" class="form-control" rows="3" placeholder=""><?php if (isset($rSeries)) { echo $rSeries["cast"]; } ?></textarea>
                                                            </div>
                                                        </div>
														
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="movie_propeties">Rating</label>
                                                            <div class="col-md-8">
                                                                <input type="number" class="form-control" id="rating" name="rating" value="<?php if (isset($rSeries)) { echo $rSeries["rating"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="movie_propeties">Director</label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="director" name="director" value="<?php if (isset($rSeries)) { echo $rSeries["director"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="movie_propeties">Release Date</label>
                                                            <div class="col-md-8">
                                                                <input type="date" class="form-control" id="releaseDate" name="releaseDate" value="<?php if (isset($rSeries)) { echo $rSeries["releaseDate"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="movie_propeties">Last Modified</label>
                                                            <div class="col-md-8">
                                                                <input type="date" class="form-control" id="last_modified" name="last_modified" value="<?php if (isset($rSeries)) { echo $rSeries["last_modified"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="movie_propeties">Seasons</label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="seasons" name="seasons" value="<?php if (isset($rSeries)) { echo $rSeries["seasons"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="movie_propeties">Back Drop Path</label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="backdrop_path" name="backdrop_path" value="<?php if (isset($rSeries)) { echo $rSeries["backdrop_path"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="movie_propeties">Youtube Trailer</label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="youtube_trailer" name="youtube_trailer" value="<?php if (isset($rSeries)) { echo $rSeries["youtube_trailer"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-8">
														<center>
														<button id="submit_series" type="submit" name="submit_series" class="btn btn-primary">Save</button>
														</center>
														</div>
                                                    </div> <!-- end col -->
                                                </div> <!-- end row -->
                                            </div>

                                    </div> <!-- end #basicwizard-->
                                </form>

                            </div> <!-- end card-body -->
                        </div> <!-- end card-->
                    </div> <!-- end col -->
                </div>
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12  text-center">TriX Codes - Admin UI</div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/jquery-nice-select/jquery.nice-select.min.js"></script>
        <script src="assets/libs/switchery/switchery.min.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>

        <!-- Plugins js-->
        <script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>

        <!-- Tree view js -->
        <script src="assets/libs/treeview/jstree.min.js"></script>
        <script src="assets/js/pages/treeview.init.js"></script>
        <script src="assets/js/pages/form-wizard.init.js"></script>

        <!-- App js-->
        <script src="assets/js/app.min.js"></script>
        
        
    </body>
</html>