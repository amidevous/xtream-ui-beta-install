MAG SDK fs plugin
===============

[![NPM version](https://img.shields.io/npm/v/mag-plugin-fs.svg?style=flat-square)](https://www.npmjs.com/package/mag-plugin-fs)
[![Gitter](https://img.shields.io/badge/gitter-join%20chat-blue.svg?style=flat-square)](https://gitter.im/DarkPark/magsdk)

This plugin provide functionality for working with file system in MAG stb device
