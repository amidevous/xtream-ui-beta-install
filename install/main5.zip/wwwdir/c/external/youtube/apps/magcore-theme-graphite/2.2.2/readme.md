magsdk theme graphite for stalker
=================================

[![NPM version](https://img.shields.io/npm/v/mag-theme-graphite.svg?style=flat-square)](https://www.npmjs.com/package/mag-theme-graphite)
[![Gitter](https://img.shields.io/badge/gitter-join%20chat-blue.svg?style=flat-square)](https://gitter.im/DarkPark/magsdk)
