MAG OSD PIP application
=======================

[![NPM version](https://img.shields.io/npm/v/mag-osd-pip.svg?style=flat-square)](https://www.npmjs.com/package/mag-osd-pip)
[![Gitter](https://img.shields.io/badge/gitter-join%20chat-blue.svg?style=flat-square)](https://gitter.im/DarkPark/magsdk)