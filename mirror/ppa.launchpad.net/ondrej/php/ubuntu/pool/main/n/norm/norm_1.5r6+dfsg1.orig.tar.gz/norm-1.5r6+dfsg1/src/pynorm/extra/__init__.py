'''
nft - Norm File Transfer Tool
By: Tom Wambold <wambold@itd.nrl.navy.mil>
'''
