#ifndef PHP_DS_VECTOR_HANDLERS_H
#define PHP_DS_VECTOR_HANDLERS_H

#include "php.h"

extern zend_object_handlers php_vector_handlers;

void php_register_vector_handlers();

#endif
