
extern zend_class_entry *phalcon_collection_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Collection_Exception);

