
extern zend_class_entry *phalcon_forms_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Forms_Exception);

