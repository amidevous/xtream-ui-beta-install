<?php
include "functions.php";
if (!isset($_SESSION['user_id'])) { header("Location: ./login.php"); exit; }


$rServerTree = Array();
$rOnDemand = Array();
$rServerTree[] = Array("id" => "source", "parent" => "#", "text" => "<strong>Stream Source</strong>", "icon" => "mdi mdi-youtube-tv", "state" => Array("opened" => true));
if (isset($_GET["id"])) {
    if (isset($_GET["import"])) { exit; }
    $rStream = getStream($_GET["id"]);
    if (!$rStream) {
        exit;
    }
    $rStreamOptions = getStreamOptions($_GET["id"]);
    $rStreamSys = getStreamSys($_GET["id"]);
    foreach ($rServers as $rServer) {
        if (isset($rStreamSys[intval($rServer["id"])])) {
            if ($rStreamSys[intval($rServer["id"])]["parent_id"] <> 0) {
                $rParent = intval($rStreamSys[intval($rServer["id"])]["parent_id"]);
            } else {
                $rParent = "source";
            }
        } else {
            $rParent = "#";
        }
        $rServerTree[] = Array("id" => $rServer["id"], "parent" => $rParent, "text" => $rServer["server_name"], "icon" => "mdi mdi-server-network", "state" => Array("opened" => true));
    }
    foreach ($rStreamSys as $rStreamItem) {
        if ($rStreamItem["on_demand"] == 1) {
            $rOnDemand[] = $rStreamItem["server_id"];
        }
    }
} else {
    foreach ($rServers as $rServer) {
        $rServerTree[] = Array("id" => $rServer["id"], "parent" => "#", "text" => $rServer["server_name"], "icon" => "mdi mdi-server-network", "state" => Array("opened" => true));
    }
}

if (isset($_GET["edit"])) {
$stream_ids = '';

	if ($_POST['select_channels']) {
		foreach($_POST['select_channels'] as $indice => $valor){
			
			if ($_POST['category_id'] == '') {
				$category_id = getChannelsByID($valor)['category_id'];
			} else {
				$category_id = $_POST['category_id'];
			}
			
			if ($_POST['gen_timestamps'] == '') {
				$gen_timestamps = getChannelsByID($valor)['gen_timestamps'];
			} else {
				$gen_timestamps = $_POST['gen_timestamps'];
			}
			
			if ($_POST['read_native'] == '') {
				$read_native = getChannelsByID($valor)['read_native'];
			} else {
				$read_native = $_POST['read_native'];
			}
			
			if ($_POST['stream_all'] == '') {
				$stream_all = getChannelsByID($valor)['stream_all'];
			} else {
				$stream_all = $_POST['stream_all'];
			}
			
			if ($_POST['allow_record'] == '') {
				$allow_record = getChannelsByID($valor)['allow_record'];
			} else {
				$allow_record = $_POST['allow_record'];
			}
			
			if ($_POST['rtmp_output'] == '') {
				$rtmp_output = getChannelsByID($valor)['rtmp_output'];
			} else {
				$rtmp_output = $_POST['rtmp_output'];
			}
			
			if ($_POST['direct_source'] == '') {
				$direct_source = getChannelsByID($valor)['direct_source'];
			} else {
				$direct_source = $_POST['direct_source'];
			}
			
			if ($_POST['custom_ffmpeg'] == '') {
				$custom_ffmpeg = getChannelsByID($valor)['custom_ffmpeg'];
			} else {
				$custom_ffmpeg = $_POST['custom_ffmpeg'];
			}
			
			if ($_POST['probesize_ondemand'] == '') {
				$probesize_ondemand = getChannelsByID($valor)['probesize_ondemand'];
			} else {
				$probesize_ondemand = $_POST['probesize_ondemand'];
			}
			
			
			
		
			

			
			
			$db->query("UPDATE streams set `category_id` = '$category_id',`gen_timestamps` = '$gen_timestamps',`read_native` = '$read_native',`stream_all` = '$stream_all',`allow_record` = '$allow_record',`rtmp_output` = '$rtmp_output',`direct_source` = '$direct_source',`custom_ffmpeg` = '$custom_ffmpeg',`probesize_ondemand` = '$probesize_ondemand' WHERE `id` = ".intval($valor).";");		
			    //  echo("UPDATE streams set `category_id` = '$category_id',`gen_timestamps` = '$gen_timestamps',`read_native` = '$read_native',`stream_all` = '$stream_all',`allow_record` = '$allow_record',`rtmp_output` = '$rtmp_output',`direct_source` = '$direct_source',`custom_ffmpeg` = '$custom_ffmpeg',`probesize_ondemand` = '$probesize_ondemand' WHERE `id` = ".intval($valor).";");		
			
			
			
			if ($_POST['user_agent'] == '') {
			} else {
				$db->query("UPDATE streams_options set `value` = '".$_POST['user_agent']."' WHERE `stream_id` = ".intval($valor).";");		
			   	//      echo("UPDATE streams_options set `value` = '".$_POST['user_agent']."' WHERE `stream_id` = ".intval($valor).";");		
			}			
			
			
			if ($_POST['on_demand'] == '') {
			} else {
				$db->query("UPDATE streams_sys set `on_demand` = '".$_POST['on_demand']."' WHERE `stream_id` = ".intval($valor).";");		
				//	  echo("UPDATE streams_sys set `on_demand` = '".$_POST['on_demand']."' WHERE `stream_id` = ".intval($valor).";");
			}

			
			if ($_POST['servers'] != '') {
				$result = $db->query("SELECT `stream_id`, `server_id` FROM `streams_sys` WHERE `stream_id` = ".intval($valor).";");
				if (($result) && ($result->num_rows > 0)) {
					while ($row = $result->fetch_assoc()) {
						$db->query("DELETE FROM `streams_sys` WHERE `stream_id` = ".$row["stream_id"].";");
					}
				}
				
				foreach($_POST['servers'] as $indice => $server){
					$db->query("INSERT INTO streams_sys (stream_id, server_id, pid, stream_info, stream_started, monitor_pid,current_source) values ('".intval($valor)."', '".$server."', '', '', NULL, NULL, NULL);");		
				}
			}	
			
			$stream_ids .= array($valor);
			
		}
		
	}
	
/*	
                if (isset($_POST["server_tree_data"])) {
                    $rStreamsAdded = Array();
                    $rServerTree = json_decode($_POST["server_tree_data"], True);
                    foreach ($rServerTree as $rServer) {
                        if ($rServer["parent"] <> "#") {
                            $rServerID = intval($rServer["id"]);
                            $rStreamsAdded[] = $rServerID;
                            if ($rServer["parent"] == "source") {
                                $rParent = "NULL";
                            } else {
                                $rParent = intval($rServer["parent"]);
                            }
                            if (in_array($rServerID, $rOnDemandArray)) {
                                $rOD = 1;
                            } else {
                                $rOD = 0;
                            }
                            
                            if (isset($rStreamExists[$rServerID])) {
                         //       $db->query("UPDATE `streams_sys` SET `parent_id` = ".$rParent.", `on_demand` = ".$rOD." WHERE `server_stream_id` = ".$rStreamExists[$rServerID].";");
                                echo("UPDATE `streams_sys` SET `parent_id` = ".$rParent.", `on_demand` = ".$rOD." WHERE `server_stream_id` = ".$rStreamExists[$rServerID].";");
								
							
                            } else {
                        //        $db->query("INSERT INTO `streams_sys`(`stream_id`, `server_id`, `parent_id`, `on_demand`) VALUES(".intval($rInsertID).", ".$rServerID.", ".$rParent.", ".$rOD.");");
						
                                echo("INSERT INTO `streams_sys`(`stream_id`, `server_id`, `parent_id`, `on_demand`) VALUES(".intval($rInsertID).", ".$rServerID.", ".$rParent.", ".$rOD.");");
                            }
                        }
                    }
                    foreach ($rStreamExists as $rServerID => $rDBID) {
                        if (!in_array($rServerID, $rStreamsAdded)) {
                         //   $db->query("DELETE FROM `streams_sys` WHERE `server_stream_id` = ".$rDBID.";");
                            echo("DELETE FROM `streams_sys` WHERE `server_stream_id` = ".$rDBID.";");
                        }
                    }
                }	
*/	

	
	
			/// Restart on edit
			if ($_POST['restart'] == '1') {
				foreach(getStreams() as $indice => $valor){
					foreach($valor['servers'] as $indice2 => $valor2){
					$IP = getStreamingServersByID(1)['server_ip'];
					$PORT = getStreamingServersByID($valor2['server_id'])['http_broadcast_port'];

					
					$panel_url = "http://{$IP}:{$PORT}/";
					$ids = $_POST['select_channels'];

					###############################################################################
					$post_data = array( 'stream_ids' => $ids);
					$opts = array( 'http' => array(
							'method' => 'POST',
							'header' => 'Content-type: application/x-www-form-urlencoded',
							'content' => http_build_query( $post_data ) ) );

					$context = stream_context_create( $opts );
					$api_result = json_decode( file_get_contents( $panel_url . "api.php?action=stream&sub=start", false, $context ), true );
					

					}
					
				}	
			} 
			
			
				
			
				
			
	
}


include "header.php"; ?>
    <link href="./update/jquery.multiselect.css" rel="stylesheet" />
    
        <div class="wrapper boxed-layout">
            <div class="container-fluid">
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <a href="./streams.php"><li class="breadcrumb-item"><i class="mdi mdi-backspace"></i> View Streams</li></a>
                                </ol>
                            </div>
                            <h4 class="page-title">Mass Edit Streams</h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 


					<div class="row">
						<div class="col-xl-12">
						
						<?php if (isset($_GET['edit'])) { ?>
						<div id="all_start_msg" style="display: block;" class="alert alert-success" role="alert"><i class="mdi mdi-checkbox-marked-circle-outline"></i> The streams were successfully edited!    
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<?php } ?>
						
							<div class="card">

								<div class="card-body">
									<form enctype="multipart/form-data" action="./masseditstreams.php?edit" method="POST" id="stream_form" autocomplete="off">
										<input type="hidden" name="server_tree_data" id="server_tree_data" value="">
										<div id="basicwizard">
											<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">
												<li class="nav-item">
													<a href="#stream-details" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2 active">
														<i class="mdi mdi-account-card-details-outline mr-1"></i>
														<span class="d-none d-sm-inline">Details</span>
													</a>
												</li>
												<li class="nav-item">
													<a href="#advanced-options" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
														<i class="mdi mdi-folder-alert-outline mr-1"></i>
														<span class="d-none d-sm-inline">Advanced</span>
													</a>
												</li>
												<li class="nav-item">
													<a href="#load-balancing" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
														<i class="mdi mdi-server-network mr-1"></i>
														<span class="d-none d-sm-inline">Servers</span>
													</a>
												</li>
											</ul>
											<div class="tab-content b-0 mb-0 pt-0">
												<div class="tab-pane active" id="stream-details">
													<div class="row">
														<div class="col-12">
															<div class="form-group row mb-4">
																<label class="col-md-4 col-form-label" for="m3u_file">Select Channels</label>
																<div class="col-md-8">																	
																	<select name="select_channels[]" multiple="multiple" id="select_channels" class="form-control">
																	<?php
																		foreach(getAllChannels() as $indice => $valor){
																			echo "<option value=\"".$valor['id']."\">".$valor['stream_display_name']."</option>";
																		}
																	
																	?>
																	</select>																	
																</div>
															</div>
															<div class="form-group row mb-4">
																<label class="col-md-4 col-form-label" for="category_id">Category Name</label>
																<div class="col-md-8">
																	<select name="category_id" id="category_id" class="form-control" data-toggle="select2">
																		<?php
																	
																		echo '<option value="0">Dont Change</option>';

																		foreach ($rCategories as $rCategory) {
		

																		?>
																		
																		<option <?php if (isset($rStream)) { if (intval($rStream["category_id"]) == intval($rCategory["id"])) { echo "selected "; } } else if ((isset($_GET["category"])) && ($_GET["category"] == $rCategory["id"])) { echo "selected "; } ?>value="<?=$rCategory["id"]?>"><?=$rCategory["category_name"]?></option>
																		
																		<?php } ?>
																	</select>
																</div>
															</div>
														</div>
														<!-- end col -->
													</div>
													<!-- end row -->
													<ul class="list-inline wizard mb-0">
														<li class="next list-inline-item float-right">
															<a href="javascript: void(0);" class="btn btn-secondary">Next</a>
														</li>
													</ul>
												</div>

												<div class="tab-pane" id="advanced-options">
													<div class="row">
														<div class="col-12">
															<div class="form-group row mb-4">
																<label style="text-align: right;" class="col-md-4 col-form-label" for="gen_timestamps">Generate PTS <i data-toggle="tooltip" data-placement="top" title="" data-original-title="Allow FFmpeg to generate presentation timestamps for you to achieve better synchronization with the stream codecs. In some streams this can cause de-sync." class="mdi mdi-information"></i></label>
																<div class="col-md-2">
																	<input name="gen_timestamps" id="gen_timestamps" type="radio" checked value=""> Dont Change
																	<input name="gen_timestamps" id="gen_timestamps" type="radio" value="1"> Yes
																	<input name="gen_timestamps" id="gen_timestamps" type="radio" value="0"> No
																</div>
																<label style="text-align: right;" class="col-md-4 col-form-label" for="read_native">Native Frames <i data-toggle="tooltip" data-placement="top" title="" data-original-title="You should always read live streams as non-native frames. However if you are streaming static video files, set this to true otherwise the encoding process will fail." class="mdi mdi-information"></i></label>
																<div class="col-md-2">
																	<input name="read_native" id="read_native" type="radio" checked value=""> Dont Change
																	<input name="read_native" id="read_native" type="radio" value="1"> Yes
																	<input name="read_native" id="read_native" type="radio" value="0"> No																
																</div>
															</div>
															<div class="form-group row mb-4">
																<label style="text-align: right;" class="col-md-4 col-form-label" for="stream_all">Stream All Codecs <i data-toggle="tooltip" data-placement="top" title="" data-original-title="This option will stream all codecs from your stream. Some streams have more than one audio/video/subtitles channels." class="mdi mdi-information"></i></label>
																<div class="col-md-2">
																	<input name="stream_all" id="stream_all" type="radio" checked value=""> Dont Change
																	<input name="stream_all" id="stream_all" type="radio" value="1"> Yes
																	<input name="stream_all" id="stream_all" type="radio" value="0"> No																	
																</div>
																<label style="text-align: right;" class="col-md-4 col-form-label" for="allow_record">Allow Recording</label>
																<div class="col-md-2">
																	<input name="allow_record" id="allow_record" type="radio" checked value=""> Dont Change
																	<input name="allow_record" id="allow_record" type="radio" value="1"> Yes
																	<input name="allow_record" id="allow_record" type="radio" value="0"> No																	
																</div>
															</div>
															<div class="form-group row mb-4">
																<label style="text-align: right;" class="col-md-4 col-form-label" for="rtmp_output">Allow RTMP Output <i data-toggle="tooltip" data-placement="top" title="" data-original-title="Enable RTMP output for this channel." class="mdi mdi-information"></i></label>
																<div class="col-md-2">
																	<input name="rtmp_output" id="rtmp_output" type="radio" checked value=""> Dont Change
																	<input name="rtmp_output" id="rtmp_output" type="radio" value="1"> Yes
																	<input name="rtmp_output" id="rtmp_output" type="radio" value="0"> No																	
																</div>
																<label style="text-align: right;" class="col-md-4 col-form-label" for="direct_source">Direct Source <i data-toggle="tooltip" data-placement="top" title="" data-original-title="Don't run source through Xtream Codes, just redirect instead." class="mdi mdi-information"></i></label>
																<div class="col-md-2">
																	<input name="direct_source" id="direct_source" type="radio" checked value=""> Dont Change
																	<input name="direct_source" id="direct_source" type="radio" value="1"> Yes
																	<input name="direct_source" id="direct_source" type="radio" value="0"> No																	
																</div>
															</div>
															<div class="form-group row mb-4">
																<label style="text-align: right;" class="col-md-4 col-form-label" for="custom_ffmpeg">Custom FFmpeg Command <i data-toggle="tooltip" data-placement="top" title="" data-original-title="In this field you can write your own custom FFmpeg command. Please note that this command will be placed after the input and before the output. If the command you will specify here is about to do changes in the output video or audio, it may require to transcode the stream. In this case, you have to use and change at least the Video/Audio Codecs using the transcoding attributes below. The custom FFmpeg command will only be used by the server(s) that take the stream from the Source." class="mdi mdi-information"></i></label>
																<div class="col-md-2">													
																	<input type="text" class="form-control" id="custom_ffmpeg" name="custom_ffmpeg" value="" placeholder="Dont Change">
																</div>
																<label style="text-align: right;" class="col-md-4 col-form-label" for="probesize_ondemand">On Demand Probesize <i data-toggle="tooltip" data-placement="top" title="" data-original-title="Adjustable probesize for ondemand streams. Adjust this setting if you experience issues with no audio." class="mdi mdi-information"></i></label>
																<div class="col-md-2">
																	<input type="text" class="form-control" id="probesize_ondemand" name="probesize_ondemand" value="" placeholder="Dont Change">
																</div>
															</div>
															<div class="form-group row mb-4">
																<label style="text-align: right;" class="col-md-4 col-form-label" for="user_agent">User Agent</label>
																<div class="col-md-8">
																	<input type="text" class="form-control" id="user_agent" name="user_agent" value="" placeholder="Dont Change">
																</div>
															</div>
														</div>
														<!-- end col -->
													</div>
													<!-- end row -->
													<ul class="list-inline wizard mb-0">
														<li class="previous list-inline-item disabled">
															<a href="javascript: void(0);" class="btn btn-secondary">Previous</a>
														</li>
														<li class="next list-inline-item float-right">
															<a href="javascript: void(0);" class="btn btn-secondary">Next</a>
														</li>
													</ul>
												</div>
												<div class="tab-pane" id="load-balancing">
													<div class="row">
														<div class="col-12">
															
	                                                        <div class="form-group row mb-4">
																<label class="col-md-4 col-form-label" for="servers">Server Tree</label>
																<div class="col-md-8">
																	<select name="servers[]" multiple="multiple" id="servers" class="form-control">
																	<option value="" selected>Dont Change</option>
																	<?php
																		foreach(getStreamingServers() as $indice => $valor){
																			echo "<option value=\"".$valor['id']."\">".$valor['server_name']."</option>";
																		}
																	
																	?>
																	</select>																		
																</div>
															</div>
															<div class="form-group row mb-4">
																<label class="col-md-4 col-form-label" for="on_demand">On Demand</label>
																<div class="col-md-8">
																	<select id="on_demand" name="on_demand" class="form-control">
																		<option value="" selected>Dont Change</option>
																		<option value="1">Yes</option>
																		<option value="0">No</option>
																	</select>
																</div>
															</div>
															<div class="form-group row mb-4">
																<label class="col-md-4 col-form-label" for="on_demand">Restart on Edit</label>
																<div class="col-md-8">
																	<select id="restart" name="restart" class="form-control">
																		<option value="1">Yes</option>
																		<option value="0">No</option>
																	</select>
																</div>
															</div>
														</div>
														<!-- end col -->
													</div>
													<!-- end row -->
													<ul class="list-inline wizard mb-0">
														<li class="previous list-inline-item disabled">
															<a href="javascript: void(0);" class="btn btn-secondary">Previous</a>
														</li>
														<li class="next list-inline-item float-right">
															<input name="submit_stream" type="submit" class="btn btn-primary" value="Edit">
														</li>
													</ul>
												</div>
											</div>
											<!-- tab-content -->
										</div>
										<!-- end #basicwizard-->
									</form>

								</div>
								<!-- end card-body -->
							</div>
							<!-- end card-->
						</div>
						<!-- end col -->
					</div>				
				
              
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

       <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/jquery-nice-select/jquery.nice-select.min.js"></script>
        <script src="assets/libs/switchery/switchery.min.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>

        <!-- Plugins js-->
        <script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>

        <!-- Tree view js -->
        <script src="assets/libs/treeview/jstree.min.js"></script>
        <script src="assets/js/pages/treeview.init.js"></script>
        <script src="assets/js/pages/form-wizard.init.js"></script>

        <!-- App js-->
        <script src="assets/js/app.min.js"></script>


		<script src="./update/jquery.multiselect.js"></script>
		<script>
		
		 $(document).ready(function() {
			 
			$('#select_channels').multiselect({
				columns: 1,
				placeholder: 'Select Channels',
				search: true,
				searchOptions: {
					'default': 'Search Channels'
				},
				selectAll: true
			});
		

            $('#server_tree').jstree({ 'core' : {
                'check_callback': function (op, node, parent, position, more) {
                    switch (op) {
                        case 'move_node':
                            if (node.id == "source") { return false; }
                            return true;
                    }
                },
                'data' : <?=json_encode($rServerTree)?>
            }, "plugins" : [ "dnd" ]
            });
			
			$("#stream_form").submit(function(e){
			  $("#server_tree_data").val(JSON.stringify($('#server_tree').jstree(true).get_json('#', {flat:true})));
                rPass = false;
                $.each($('#server_tree').jstree(true).get_json('#', {flat:true}), function(k,v) {
                    if (v.parent == "source") {
                        rPass = true;
                    }
                });
                if (rPass == false) {
                    e.preventDefault();
                    $.toast("Select at least one server.");
                }
            });
			
		});	
			
	</script> 
        
        <!-- App js-->
        <script src="assets/js/app.min.js"></script>
    </body>
</html>