Application localization files
==============================

The directory contains generated localization JSON files from [gettext sources](../../src/lang/).
