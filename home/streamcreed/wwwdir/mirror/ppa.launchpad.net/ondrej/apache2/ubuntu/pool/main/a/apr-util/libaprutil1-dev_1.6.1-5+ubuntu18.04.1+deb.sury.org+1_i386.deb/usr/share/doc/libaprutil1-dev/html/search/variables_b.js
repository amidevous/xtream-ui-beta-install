var searchData=
[
  ['major',['major',['../structapr__redis__stats__t.html#a72239567fad6d2024701a9dc7b4ee1bb',1,'apr_redis_stats_t']]],
  ['maxmemory',['maxmemory',['../structapr__redis__stats__t.html#afd616b98b5b2ce19d525d7afb9e557d6',1,'apr_redis_stats_t']]],
  ['minor',['minor',['../structapr__redis__stats__t.html#a1acf2f99777aa17494cc65a058625e6f',1,'apr_redis_stats_t']]],
  ['mmap',['mmap',['../structapr__bucket__mmap.html#a66e9385752aaacb7fef7e96db62f1920',1,'apr_bucket_mmap::mmap()'],['../unionapr__bucket__structs.html#a627c4ca697f06bbf4226c8c2acd93cbc',1,'apr_bucket_structs::mmap()']]]
];
