<?php




if (isset($_GET["action"])) {
	

		if ($_GET["action"] == "all_stream") {
			$rSub = $_GET["sub"];
			if ($rSub == 'start') {
				
				foreach(getStreams() as $indice => $valor){
					foreach($valor['servers'] as $indice2 => $valor2){
					$IP = getStreamingServersByID(1)['server_ip'];
					$PORT = getStreamingServersByID($valor2['server_id'])['http_broadcast_port'];

					
					$panel_url = "http://{$IP}:{$PORT}/";
					$ids[] = $valor['id'];

					###############################################################################
					$post_data = array( 'stream_ids' => $ids);
					$opts = array( 'http' => array(
							'method' => 'POST',
							'header' => 'Content-type: application/x-www-form-urlencoded',
							'content' => http_build_query( $post_data ) ) );

					$context = stream_context_create( $opts );
					$api_result = json_decode( file_get_contents( $panel_url . "api.php?action=stream&sub=start", false, $context ), true );
					

					}
				}
				
			}
			if ($rSub == 'stop') {
				
				foreach(getStreams() as $indice => $valor){
					foreach($valor['servers'] as $indice2 => $valor2){
					$IP = getStreamingServersByID(1)['server_ip'];
					$PORT = getStreamingServersByID($valor2['server_id'])['http_broadcast_port'];
					$panel_url = "http://{$IP}:{$PORT}/";
					$ids[] = $valor['id'];

					###############################################################################
					$post_data = array( 'stream_ids' => $ids);
					$opts = array( 'http' => array(
							'method' => 'POST',
							'header' => 'Content-type: application/x-www-form-urlencoded',
							'content' => http_build_query( $post_data ) ) );

					$context = stream_context_create( $opts );
					$api_result = json_decode( file_get_contents( $panel_url . "api.php?action=stream&sub=stop", false, $context ), true );
					}
				}
				
			}
		}
}