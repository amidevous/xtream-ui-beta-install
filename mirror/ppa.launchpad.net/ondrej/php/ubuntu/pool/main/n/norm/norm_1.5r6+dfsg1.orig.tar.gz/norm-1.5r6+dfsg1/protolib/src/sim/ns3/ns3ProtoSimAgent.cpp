
#include "ns3ProtoSimAgent.h"

Ns3ProtoSimAgent::Ns3ProtoSimAgent()
{
}

Ns3ProtoSimAgent::~Ns3ProtoSimAgent()
{
}
