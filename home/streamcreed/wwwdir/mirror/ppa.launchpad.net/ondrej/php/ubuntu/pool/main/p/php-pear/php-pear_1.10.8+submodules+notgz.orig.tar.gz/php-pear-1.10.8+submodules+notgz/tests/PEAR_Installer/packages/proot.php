<?php $a = '@test@'; ?>
