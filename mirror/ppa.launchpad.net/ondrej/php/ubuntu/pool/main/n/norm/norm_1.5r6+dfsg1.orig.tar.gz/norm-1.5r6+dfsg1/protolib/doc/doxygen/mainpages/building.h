
/**

@page mainpage_building Building

@li @subpage building_with_waf
@li @subpage building_with_make
@li @subpage building_with_visual_studio
@li @subpage building_examples_with_waf
@li @subpage building_protolibJni_with_waf (Protolib-Jni is a java native library that allows 
java applications access to the Protolib ProtoPipe class).

*/
