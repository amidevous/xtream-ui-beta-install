var searchData=
[
  ['error_20codes',['Error Codes',['../group__apu__errno.html',1,'']]],
  ['end_5ftransaction',['end_transaction',['../structapr__dbd__driver__t.html#a8ec55cbddf69f4d371017d0c985abe76',1,'apr_dbd_driver_t']]],
  ['errcode',['errcode',['../structapr__dbm__t.html#a130a628921f4c46241d09476f8a3090c',1,'apr_dbm_t']]],
  ['errmsg',['errmsg',['../structapr__dbm__t.html#adc3defc90b90fe3411c099631f75a653',1,'apr_dbm_t']]],
  ['error',['error',['../structapr__dbd__driver__t.html#a96a1e0b8f3790421e1027671a51ca698',1,'apr_dbd_driver_t']]],
  ['escape',['escape',['../structapr__dbd__driver__t.html#a60deca4d8496e4ce2a4526c7a5733839',1,'apr_dbd_driver_t']]],
  ['evictions',['evictions',['../structapr__memcache__stats__t.html#ad430486ea11c0e5f7b70c9c2b95a216c',1,'apr_memcache_stats_t']]],
  ['exists',['exists',['../structapr__dbm__type__t.html#ab3192948d859017eec8c350d55f8aa72',1,'apr_dbm_type_t']]]
];
