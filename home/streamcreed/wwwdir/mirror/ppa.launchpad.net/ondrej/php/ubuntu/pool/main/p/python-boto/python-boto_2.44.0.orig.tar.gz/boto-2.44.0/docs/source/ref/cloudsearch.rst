.. ref-cloudsearch

===========
Cloudsearch
===========

boto.cloudsearch
----------------

.. automodule:: boto.cloudsearch
   :members:
   :undoc-members:

boto.cloudsearch.domain
-----------------------

.. automodule:: boto.cloudsearch.domain
   :members:
   :undoc-members:

boto.cloudsearch.exceptions
-----------------------

.. automodule:: boto.cloudsearch.exceptions
   :members:
   :undoc-members:

boto.cloudsearch.layer1
-----------------------

.. automodule:: boto.cloudsearch.layer1
   :members:
   :undoc-members:

boto.cloudsearch.layer2
-----------------------

.. automodule:: boto.cloudsearch.layer2
   :members:
   :undoc-members:

boto.cloudsearch.optionstatus
-----------------------------

.. automodule:: boto.cloudsearch.optionstatus
   :members:
   :undoc-members:

boto.cloudsearch.search
-----------------------

.. automodule:: boto.cloudsearch.search
   :members:
   :undoc-members:

boto.cloudsearch.document
-------------------------

.. automodule:: boto.cloudsearch.document
   :members:
   :undoc-members:
