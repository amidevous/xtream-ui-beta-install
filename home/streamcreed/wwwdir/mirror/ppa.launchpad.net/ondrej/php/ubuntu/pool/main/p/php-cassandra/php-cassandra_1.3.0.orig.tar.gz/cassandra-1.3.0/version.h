#ifndef PHP_DRIVER_VERSION_H
#define PHP_DRIVER_VERSION_H

/* Define Extension and Version Properties */
#define PHP_DRIVER_NAME         "cassandra"
#define PHP_DRIVER_MAJOR        1
#define PHP_DRIVER_MINOR        3
#define PHP_DRIVER_RELEASE      0
#define PHP_DRIVER_STABILITY    "stable"
#define PHP_DRIVER_VERSION      "1.3.0"
#define PHP_DRIVER_VERSION_FULL "1.3.0"

#endif /* PHP_DRIVER_VERSION_H */
