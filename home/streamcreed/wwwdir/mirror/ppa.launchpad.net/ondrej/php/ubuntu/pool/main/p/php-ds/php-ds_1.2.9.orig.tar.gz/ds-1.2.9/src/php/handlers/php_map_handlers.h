#ifndef DS_MAP_HANDLERS_H
#define DS_MAP_HANDLERS_H

#include "php.h"

extern zend_object_handlers php_map_handlers;

void php_ds_register_map_handlers();

#endif
