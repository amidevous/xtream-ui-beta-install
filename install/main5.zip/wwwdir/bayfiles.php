<?php
$url = $_GET["url"];
$ch = curl_init($url);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch,CURLOPT_HEADER, false);
$res = curl_exec( $ch );
preg_match('/<a type="button" id="download-url"[\s\n]+class="btn btn-primary btn-block"[\s\n]+href="(.*?)">/', $res, $download_link);
header('Location: ' . $download_link[1] . '');   
//echo $download_link[1];
