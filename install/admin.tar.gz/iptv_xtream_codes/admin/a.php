<?php
include "./functions.php";
print_r(getCategoriesByID(1));

?>